(function(){
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const baseContent = window.KKK_CONTENT || {};
  let content = baseContent;
  try { const draft = localStorage.getItem('kkk_content_draft'); if(draft) content = JSON.parse(draft); } catch(e) {}
  const scenarios = content.scenarios || [];
  let current = 0, picked = null, score = 0, decisions = [];
  const subject = $('#subject-select');
  const board = $('#board-select');
  $('#year').textContent = new Date().getFullYear();
  if(content.meta?.heroTitle){ const parts=content.meta.heroTitle.split(/\s+/); const half=Math.ceil(parts.length/2); $('#hero-title').innerHTML = `${escapeHtml(parts.slice(0,half).join(' '))}<br /><em>${escapeHtml(parts.slice(half).join(' '))}</em>`; }
  if(content.meta?.heroSubtitle) $('#hero-subtitle').textContent=content.meta.heroSubtitle;
  if(content.meta?.defaultBoard){ const opt=[...board.options].find(o=>o.textContent===content.meta.defaultBoard); if(opt) board.value=opt.value; }

  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function renderScenario(){
    const item=scenarios[current]; if(!item) return;
    picked=null; $('#feedback-panel').hidden=true; $('#scenario-content').hidden=false;
    $('#progress-label').textContent=`DECISION ${String(current+1).padStart(2,'0')} / ${String(scenarios.length).padStart(2,'0')}`;
    $('#progress-fill').style.width=`${((current+1)/scenarios.length)*100}%`;
    $('#scenario-category').textContent=item.category;
    $('#scenario-title').textContent=item.title;
    $('#scenario-context').textContent=item.context;
    $('#scenario-choices').innerHTML=(item.options||[]).map((o,i)=>`<button class="choice-button" type="button" data-choice="${i}"><span class="choice-letter">${String.fromCharCode(65+i)}</span><span class="choice-copy"><b>${escapeHtml(o.text)}</b><small>${escapeHtml(o.detail)}</small></span></button>`).join('');
    $$('.choice-button').forEach(btn=>btn.addEventListener('click',()=>choose(Number(btn.dataset.choice))));
    $('#next-button').disabled=true; $('#next-button').innerHTML='Choose an option first <span aria-hidden="true">→</span>';
    $('#round-footnote').textContent='No countdown. Think it through before you choose.';
  }
  function choose(index){
    if(picked!==null) return;
    const item=scenarios[current], option=item.options[index]; picked=index; score+=Number(option.points)||0;
    $$('.choice-button').forEach((b,i)=>{b.disabled=true;if(i===index)b.classList.add('selected');});
    const isBest=index===item.best;
    $('#scenario-content').hidden=true;
    $('#feedback-panel').hidden=false;
    $('#feedback-panel').innerHTML=`<div class="feedback-head"><span class="feedback-badge">${isBest?'✓':'↗'}</span><b>${isBest?'A strong exam-hall decision':'Here is the trade-off'}</b></div><p class="feedback-reason">${escapeHtml(option.feedback)}</p><p><b>Try to remember:</b> ${escapeHtml(item.lesson)}</p>`;
    decisions.push({scenario:item.title,choice:option.text,points:option.points,best:isBest,lesson:item.lesson});
    const next=$('#next-button'); next.disabled=false; next.innerHTML=current===scenarios.length-1?'See my strategy review <span aria-hidden="true">→</span>':'Next decision <span aria-hidden="true">→</span>';
    $('#round-footnote').textContent=`You earned ${option.points} / 25 strategy points in this situation.`;
  }
  function showResults(){
    const max=scenarios.length*25, pct=Math.round(score/max*100);
    const chosenSubject=subject?.value||'General'; const chosenBoard=board?.value||'Selected board';
    $('#progress-label').textContent='ROUND COMPLETE'; $('#progress-fill').style.width='100%';
    $('#scenario-content').hidden=true; $('#feedback-panel').hidden=false;
    const strong=decisions.filter(d=>d.best).length;
    $('#feedback-panel').innerHTML=`<div class="results-top"><div><div class="scenario-category">YOUR STRATEGY REVIEW</div><h3 style="font:700 25px Manrope,sans-serif;margin:7px 0 0">${pct>=85?'Thoughtful moves.':pct>=65?'A good base to build on.':'A useful round of practice.'}</h3><p style="margin:6px 0 0;color:#718077;font-size:11px">You made ${strong} of ${scenarios.length} decisions that matched the strongest strategy in these examples.</p></div><div class="result-score"><strong>${score}</strong><small>/ ${max}</small></div></div><div class="result-list">${decisions.map((d,i)=>`<div class="result-row"><span class="result-number">0${i+1}</span><span class="result-copy"><b>${escapeHtml(d.scenario)}</b><small>${escapeHtml(d.choice)}</small></span><span class="result-points ${d.best?'good':'neutral'}">${d.points}/25</span></div>`).join('')}</div><p class="result-disclaimer">Practice context: ${escapeHtml(chosenBoard)} · ${escapeHtml(chosenSubject)}. This is a coaching rubric for decision-making, not a prediction of exam marks or an official paper blueprint. Your subject knowledge and actual marking scheme still matter.</p>`;
    $('#next-button').disabled=false; $('#next-button').innerHTML='Play another round ↺'; $('#round-footnote').textContent='Keep the lesson that helps you most. You do not need a perfect score.';
  }
  $('#next-button').addEventListener('click',()=>{if(picked===null)return;if(current<scenarios.length-1){current++;renderScenario();}else{const isResult=$('#progress-label').textContent==='ROUND COMPLETE';if(isResult){current=0;score=0;decisions=[];renderScenario();}else showResults();}});
  if(scenarios.length) renderScenario(); else $('#scenario-content').innerHTML='<p>Practice scenarios are being prepared.</p>';

  const paperMaps=content.paperMaps || {};
  function renderPaperMap(size){const sections=paperMaps[String(size)]||[];$('#paper-map-label').textContent=`ILLUSTRATIVE ${size}-MARK MAP`;$('#paper-map-total').innerHTML=`${size} <small>marks</small>`;$('#paper-sections').innerHTML=sections.map(s=>`<article class="map-section"><div class="map-section-top"><span class="map-section-letter">${s[0]}</span><span class="map-section-marks">${s[3]}</span></div><h4>${s[1]}</h4><b class="map-question-count">${s[2]}</b><p>${s[4]}</p></article>`).join('');$$('.map-toggle-button').forEach(b=>{const on=b.dataset.paper===String(size);b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});}
  $$('.map-toggle-button').forEach(b=>b.addEventListener('click',()=>renderPaperMap(Number(b.dataset.paper))));renderPaperMap(80);
  board?.addEventListener('change',()=>{$('#paper-map-disclaimer').textContent=`Selected context: ${board.value}. This map remains an illustrative practice structure, not an official board pattern. Confirm the current section layout and marking scheme from your board.`;});

  const planInputs=$$('[data-plan]');
  function updatePlan(){let total=0;const values=planInputs.map(i=>{const n=Math.max(0,Math.min(180,Number(i.value)||0));total+=n;return n;});$('#plan-total').innerHTML=`${total} <small>/ 180 min</small>`;const status=$('#plan-status');if(total===180){status.className='plan-status status-good';status.innerHTML='Balanced plan <span>✓</span>';}else if(total<180){status.className='plan-status status-warn';status.textContent=`${180-total} min unallocated`; }else{status.className='plan-status status-warn';status.textContent=`${total-180} min over budget`;}const bar=$('#plan-bar');const spans=$$('span',bar);values.forEach((v,i)=>spans[i].style.width=`${total?Math.max(0,v/total*100):0}%`);bar.style.opacity=total?1:.35;}
  planInputs.forEach(i=>i.addEventListener('input',updatePlan)); updatePlan();

  const presentation=content.presentation||{};let activeType='science';
  function renderChecklist(type){activeType=type;const data=presentation[type];if(!data)return;$('#presentation-title').textContent=data.title;$('#presentation-desc').textContent=data.description;$('#checklist-grid').innerHTML=data.items.map((it,i)=>`<label class="check-item"><input type="checkbox" data-check="${i}" /><span><b>${escapeHtml(it[0])}</b><small>${escapeHtml(it[1])}</small></span></label>`).join('');$$('.presentation-tab').forEach(t=>{const on=t.dataset.type===type;t.classList.toggle('active',on);t.setAttribute('aria-selected',String(on));});updateCheckCount();$$('[data-check]').forEach(c=>c.addEventListener('change',updateCheckCount));}
  function updateCheckCount(){const all=$$('[data-check]'),done=all.filter(c=>c.checked).length;$('#check-count').textContent=`${done} of ${all.length} habits checked`;}
  $$('.presentation-tab').forEach(t=>t.addEventListener('click',()=>renderChecklist(t.dataset.type)));$('#reset-checks').addEventListener('click',()=>{$$('[data-check]').forEach(c=>c.checked=false);updateCheckCount();});
  function subjectType(){const s=subject?.value||'';if(s.includes('Mathematics'))return 'maths';if(s==='General Science')return 'science';if(s==='Social Science')return 'humanities';if(s==='English'||s==='Hindi')return 'language';return 'short';}
  subject?.addEventListener('change',()=>{const s=subject.value;$('#round-footnote').textContent=`Practice context: ${s}. The scenarios train exam decisions; the checklist below now matches your subject.`;renderChecklist(subjectType());});
  renderChecklist(subjectType());
})();
