# Kalam Ka Khel

A mobile-first exam strategy practice website. The first release contains an interactive strategy round, a 180-minute planning tool, answer-presentation checklists, and a local content editor.

## Open the website

Open `index.html` in a modern browser. The site is built with plain HTML, CSS and JavaScript and does not require a build step or paid hosting. The Google Fonts link is optional; the site falls back to system fonts when offline.

## Files

- `index.html` — student-facing website
- `styles.css` — responsive design and touch-friendly layout
- `app.js` — strategy game, planner and presentation checklist logic
- `content.js` — all editable learning content and defaults
- `admin.html` and `admin.js` — local content editor

## Admin editing

1. Open `admin.html` on the same browser/device.
2. Edit the site message, decision scenarios, or answer checklists.
3. Use **Save local preview** to test the changes on this browser.
4. Use **Export content.js** to download the updated content file.
5. Replace the existing `content.js` file on your hosting service with the exported file to publish the changes to all visitors.

Important: this is a static-site editor. It does not yet have a secure admin login, cloud database, or one-click publishing. Local previews are stored only in the browser that made them. Anyone who can access the public admin page can open the editor; do not treat it as protected. For a real owner-only admin dashboard, connect a server-side authentication service and hosted database before adding payments or user accounts.

## Publish for free

The site can be hosted on a static hosting service that supports HTML/CSS/JS, such as GitHub Pages, Cloudflare Pages or Netlify. Upload the contents of this folder (not the outer ZIP) to the host's project. Connect a custom domain only when you are ready; the free host-provided subdomain is sufficient for a test launch.

## Product and learning notes

- The strategy score is an instructional rubric, not a prediction of board-exam marks.
- Example paper timing and scenarios are illustrative. They are not an official ASSEB/SEBA or CBSE paper blueprint.
- Students should use the current official syllabus, paper instructions and teacher guidance for their actual board.
- No sign-in or personal student data is collected by this static prototype.
