/* Kalam Ka Khel content file. Export changes from Admin Studio and replace this file to publish. */
window.KKK_CONTENT = {
  "meta": {
    "heroTitle": "Play the paper smarter.",
    "heroSubtitle": "You already study the chapters. Now practise the decisions that happen between the first bell and the final minute.",
    "defaultBoard": "ASSEB / SEBA · Class 10"
  },
  "scenarios": [
    {
      "id": "opening-move",
      "category": "FIRST MOVE",
      "title": "The paper has just begun. What do you attempt first?",
      "context": "You have scanned the paper. One question feels familiar and quick. Another is worth more marks but may take longer.",
      "options": [
        {
          "text": "Start with the familiar 2-mark question",
          "detail": "About 3 minutes · High confidence",
          "points": 25,
          "feedback": "A strong opening. You are securing a likely answer quickly, building rhythm and protecting time for harder questions."
        },
        {
          "text": "Start with the 5-mark question you know well",
          "detail": "About 10 to 12 minutes · High confidence",
          "points": 21,
          "feedback": "This can be a sensible move when you are confident and have a clear time cap. The risk is spending too long on one answer before securing shorter marks."
        },
        {
          "text": "Start with the unfamiliar 5-mark question",
          "detail": "Could take 18 minutes or more · Low confidence",
          "points": 9,
          "feedback": "This is a risky opening. A difficult question can consume attention before you have secured the marks you can already earn. Mark it and return with a time limit."
        }
      ],
      "best": 0,
      "lesson": "Start with a question you can answer accurately in a reasonable time. A good first move creates momentum without trapping you."
    },
    {
      "id": "time-cap",
      "category": "KNOW WHEN TO MOVE",
      "title": "You have spent 8 minutes on a 5-mark question. The next step is still unclear.",
      "context": "You have written part of the answer, but you are repeating the same thought. Several questions are still untouched.",
      "options": [
        {
          "text": "Keep trying until the answer feels complete",
          "detail": "No time cap · Other questions wait",
          "points": 6,
          "feedback": "This can turn into a time trap. More minutes do not always create more marks, especially when your thinking has stopped moving forward."
        },
        {
          "text": "Write the valid points you know, mark it and move on",
          "detail": "Save the work · Return later if time allows",
          "points": 25,
          "feedback": "A disciplined choice. Preserve the correct work you have, leave space to return if useful, and protect time for questions you can finish now."
        },
        {
          "text": "Cross it out and leave the whole answer blank",
          "detail": "Move on immediately",
          "points": 13,
          "feedback": "Moving on is sensible, but discarding valid work is not. Keep correct steps or points that may earn credit, then return later if time permits."
        }
      ],
      "best": 1,
      "lesson": "Use a time cap. When progress stops, preserve what is correct, leave a clear mark to return, and continue."
    },
    {
      "id": "mark-time",
      "category": "TIME VALUE",
      "title": "How much time should you reserve for a 5-mark answer?",
      "context": "Your paper is 180 minutes. You still need to answer other sections and keep time to review. This question needs a few clear steps, not a long essay.",
      "options": [
        {
          "text": "About 5 minutes, whatever the question asks",
          "detail": "Very fast · Risk of missing steps",
          "points": 10,
          "feedback": "Speed is useful only when the answer remains complete. A fixed 5-minute cap may be too tight for a question that needs reasoning, steps or a diagram."
        },
        {
          "text": "Set a rough 10 to 12 minute cap, then adjust to the question",
          "detail": "A planning guide · Watch your progress",
          "points": 25,
          "feedback": "A reasonable starting guide for this example. The exact time should follow the marks, complexity and your own pace. Check progress rather than watching the clock constantly."
        },
        {
          "text": "Spend 18 to 20 minutes to make it perfect",
          "detail": "High polish · Less time for the rest",
          "points": 7,
          "feedback": "Over-polishing one answer can cost you opportunities elsewhere. Aim for a complete, readable answer, not a perfect-looking page."
        }
      ],
      "best": 1,
      "lesson": "Use marks and complexity to set a rough time budget. A cap is a guide to help you move, not a rule that fits every question."
    },
    {
      "id": "final-minutes",
      "category": "THE FINAL 15 MINUTES",
      "title": "The last 15 minutes begin. What is your best move?",
      "context": "You have one short question left, one answer with a missing unit, and a calculation you should verify. You do not have time to rewrite everything.",
      "options": [
        {
          "text": "Start rewriting a long answer to make it neater",
          "detail": "May improve appearance · Uses the full review window",
          "points": 5,
          "feedback": "A rewrite is rarely the best use of the final minutes unless the answer is genuinely unreadable. Protect the time for missing work and checkable errors."
        },
        {
          "text": "Answer the short question, then check units and omissions",
          "detail": "Secure the remaining answer · Review high-risk details",
          "points": 25,
          "feedback": "A strong final pass. Complete the short question first, then check units, question numbers, diagrams, unanswered parts and obvious calculation slips."
        },
        {
          "text": "Stop writing and wait for the bell",
          "detail": "No final check",
          "points": 3,
          "feedback": "You are giving up useful time. A calm final scan can catch an omitted sub-question, missing unit or unlabelled diagram."
        }
      ],
      "best": 1,
      "lesson": "Keep a review window. Check completeness and correctness before spending time on cosmetic changes."
    }
  ],
  "presentation": {
    "short": {
      "title": "A short answer that gets to the point",
      "description": "For 1 to 2 mark questions. Be direct and make the key idea easy to find.",
      "items": [
        [
          "Answer the command word",
          "Define, state, name or give a reason as the question asks."
        ],
        [
          "Put the main point first",
          "Do not hide the answer inside a long introduction."
        ],
        [
          "Use the correct keyword",
          "Choose the precise term, date, unit or name where required."
        ],
        [
          "Keep it relevant",
          "Write enough to answer the marks. Avoid unrelated detail."
        ]
      ]
    },
    "maths": {
      "title": "A solution the examiner can follow",
      "description": "Show a logical path from the given information to the final result.",
      "items": [
        [
          "Write the relevant formula or theorem",
          "Make clear which rule you are applying."
        ],
        [
          "Show substitution and working",
          "Keep steps in order so the method is visible."
        ],
        [
          "Keep signs and units clear",
          "Do not skip a step where an error could hide."
        ],
        [
          "Mark the final result clearly",
          "Use the required unit and a neat final line."
        ]
      ]
    },
    "science": {
      "title": "A science answer with visible evidence",
      "description": "Make definitions, processes, equations and diagrams easy to locate.",
      "items": [
        [
          "Start with the direct scientific point",
          "Use the correct concept or definition."
        ],
        [
          "Include key terms",
          "Use precise vocabulary rather than vague wording."
        ],
        [
          "Draw and label when it adds value",
          "Keep diagrams relevant, clear and correctly labelled."
        ],
        [
          "Check equations and units",
          "Balance equations where required and show units in numerical answers."
        ]
      ]
    },
    "humanities": {
      "title": "A structured Social Science answer",
      "description": "Organise facts and explanation so each point is easy to identify.",
      "items": [
        [
          "Use a relevant heading if useful",
          "Make the topic of the answer clear."
        ],
        [
          "Separate distinct points",
          "Use short paragraphs or numbered points when suitable."
        ],
        [
          "Keep dates, names and terms accurate",
          "Accuracy matters more than decorative presentation."
        ],
        [
          "Explain the connection",
          "Do not list facts without answering what the question asks."
        ]
      ]
    },
    "language": {
      "title": "A clear and complete language answer",
      "description": "Follow the format and communicate your idea with control.",
      "items": [
        [
          "Follow the requested format",
          "Use the correct structure for the task."
        ],
        [
          "Answer the exact prompt",
          "Stay focused on the topic and audience."
        ],
        [
          "Use clear paragraphs",
          "Keep ideas in a sensible order."
        ],
        [
          "Check grammar and word limit",
          "Leave time to check spelling, punctuation and length."
        ]
      ]
    }
  },
  "paperMaps": {
    "80": [
      [
        "A",
        "Objective / MCQ",
        "20 questions",
        "20 marks",
        "Quick recall, concepts and careful reading"
      ],
      [
        "B",
        "Very short answer",
        "5 questions",
        "10 marks",
        "Brief facts, definitions or one-step responses"
      ],
      [
        "C",
        "Short answer",
        "6 questions",
        "18 marks",
        "A few clear points, reasons or method steps"
      ],
      [
        "D",
        "Long answer",
        "4 questions",
        "20 marks",
        "Structured explanations, proofs or detailed answers"
      ],
      [
        "E",
        "Application / case",
        "2 questions",
        "12 marks",
        "Use information from a situation or source"
      ]
    ],
    "100": [
      [
        "A",
        "Objective / MCQ",
        "25 questions",
        "25 marks",
        "Quick recall, concepts and careful reading"
      ],
      [
        "B",
        "Very short answer",
        "5 questions",
        "10 marks",
        "Brief facts, definitions or one-step responses"
      ],
      [
        "C",
        "Short answer",
        "10 questions",
        "30 marks",
        "A few clear points, reasons or method steps"
      ],
      [
        "D",
        "Long answer",
        "5 questions",
        "25 marks",
        "Structured explanations, proofs or detailed answers"
      ],
      [
        "E",
        "Application / case",
        "2 questions",
        "10 marks",
        "Use information from a situation or source"
      ]
    ]
  }
};
